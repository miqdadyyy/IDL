<?php

namespace App\Exports;

use App\Desa;
use App\Kecamatan;
use App\Penduduk;
use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromView;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Request;
use PhpOffice\PhpSpreadsheet\Shared\Date;
use PhpOffice\PhpSpreadsheet\Style\NumberFormat;
use PhpOffice\PhpSpreadsheet\Style\Border;
use Maatwebsite\Excel\Concerns\WithColumnFormatting;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Events\AfterSheet;
class RastradaExport implements FromView, ShouldAutoSize , WithColumnFormatting , WithEvents
{
    public function columnFormats(): array
    {
        return [
            'B' => NumberFormat::FORMAT_NUMBER,
            'C' => NumberFormat::FORMAT_NUMBER,
        ];
    }

    /**
     * @return array
     */
    public function registerEvents(): array
    {
        return [
            AfterSheet::class    => function(AfterSheet $event) {
                $cellRange = 'A1:H1'; // All headers
                $event->sheet->getDelegate()->getStyle($cellRange)->getFont()->setSize(14);
            },
        ];
    }

    public function view(): View
    {
    	$kecamatans = Kecamatan::all();
        $desas = Desa::all();
        $lokasi = '';
        $nama_desa = Request::get('desa');
        $nama_kecamatan = Request::get('kecamatan');
        if(Request::has('kecamatan') && Request::get('kecamatan') <> ''){
            if($nama_kecamatan <> 'all' && $nama_desa <> 'all'){
                
                $penduduks =  Penduduk::where('kecamatan_id',$nama_kecamatan)->where('desa_id',$nama_desa)->whereHas('info',function($q){
                        $q->where('pendapatan_KK',4)->where('dinding_rumah','>=',3)->where('bahanbakar_masak','>=',3)->where('frekuensi_makan',4);    
                    })->orderBy('kecamatan_id')->get();
                $lokasi .= ' Kecamatan '. Kecamatan::find($nama_kecamatan)->name . ' Desa ' . Desa::find($nama_kecamatan)->name;
            }
            elseif($nama_kecamatan <> 'all'){
                $penduduks =  Penduduk::where('kecamatan_id',$nama_kecamatan)->whereHas('info',function($q){
                        $q->where('pendapatan_KK',4)->where('dinding_rumah','>=',3)->where('bahanbakar_masak','>=',3)->where('frekuensi_makan',4);    
                    })->orderBy('desa_id')->get();
                $lokasi .= ' Kecamatan '. Kecamatan::find($nama_kecamatan)->name;
            }
            elseif($nama_desa <> 'all'){
                $penduduks =  Penduduk::where('desa_id',$nama_desa)->whereHas('info',function($q){
                        $q->where('pendapatan_KK',4)->where('dinding_rumah','>=',3)->where('bahanbakar_masak','>=',3)->where('frekuensi_makan',4);    
                    })->get();
                $lokasi .= ' Desa ' . Desa::find($nama_desa)->name;
            }

        }
        else{   
             $penduduks =  Penduduk::whereHas('info',function($q){
                        $q->where('pendapatan_KK',4)->where('dinding_rumah','>=',3)->where('bahanbakar_masak','>=',3)->where('frekuensi_makan',4);    
                    })->with(['desa.kecamatan','info'])->get();
            $lokasi = 'Jember';
        }
        return view('exports.rastrada', [
            'penduduks' => $penduduks
        ]);
    }
}