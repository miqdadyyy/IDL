<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Kecamatan extends Model
{
    
    public function desas()
    {
        return $this->hasMany('App\Desa');
    }

}
