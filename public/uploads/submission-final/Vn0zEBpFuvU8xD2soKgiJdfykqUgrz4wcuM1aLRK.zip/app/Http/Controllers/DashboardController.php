<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Penduduk;
class DashboardController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $penduduk = Penduduk::count();
        $verval = Penduduk::has('info')->count(); 
        $sisa = $penduduk - $verval ;
        return view('dashboard.home',compact('penduduk','verval','sisa'));
    }
}
