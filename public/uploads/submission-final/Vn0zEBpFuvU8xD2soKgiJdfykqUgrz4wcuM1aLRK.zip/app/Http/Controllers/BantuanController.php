<?php

namespace App\Http\Controllers;
use App\Desa;
use App\Kecamatan;
use App\Penduduk;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Session;
use Yajra\Datatables\Datatables;
use App\Exports\RastradaExport;
use Excel;
use Auth;
class BantuanController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('staff');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    
    public function rastrada(Request $request)
    {
        $kecamatans = Kecamatan::orderBy('name')->get();
        $desas = Desa::all();
        $lokasi = '';
        if($request->has('kecamatan')){
            if($request->kecamatan <> 'all' && $request->desa <> 'all'){
                
                $penduduks =  Penduduk::where('kecamatan_id',$request->kecamatan)->where('desa_id',$request->desa)->whereHas('info',function($q){
                        $q->where('pendapatan_KK',4)->where('dinding_rumah','>=',3)->where('bahanbakar_masak','>=',3)->where('frekuensi_makan',4)->where('tabungan', '>=' , 3);    
                    })->orderBy('kecamatan_id');
                $jumlahPenduduk = $penduduks->count();
                $penduduks = $penduduks->paginate();
                Session::flash('desa_id',$request->desa);
                $lokasi .= ' Kecamatan '. Kecamatan::find($request->kecamatan)->name . ' Desa ' . Desa::find($request->desa)->name;
            }
            elseif($request->kecamatan <> 'all' && $request->desa == 'all'){
                $penduduks =  Penduduk::where('kecamatan_id',$request->kecamatan)->whereHas('info',function($q){
                        $q->where('pendapatan_KK',4)->where('dinding_rumah','>=',3)->where('bahanbakar_masak','>=',3)->where('frekuensi_makan',4)->where('frekuensi_makan',4)->where('tabungan', '>=' , 3);;    
                    })->orderBy('desa_id');
                $jumlahPenduduk = $penduduks->count();
                $penduduks = $penduduks->paginate();
                $lokasi .= ' Kecamatan '. Kecamatan::find($request->kecamatan)->name;
            }
            elseif($request->desa <> 'all'){
                $penduduks =  Penduduk::where('desa_id',$request->desa)->whereHas('info',function($q){
                        $q->where('pendapatan_KK',4)->where('dinding_rumah','>=',3)->where('bahanbakar_masak','>=',3)->where('frekuensi_makan',4)->where('frekuensi_makan',4)->where('tabungan', '>=' , 3);;    
                    });
                $jumlahPenduduk = $penduduks->count();
                $penduduks = $penduduks->paginate();
                Session::flash('desa_id',$request->desa);
                $lokasi .= ' Desa ' . Desa::find($request->desa)->name;
            }
            Session::flash('kecamatan',$request->kecamatan);

        }
        else{   
             $penduduks =  Penduduk::whereHas('info',function($q){
                        $q->where('pendapatan_KK',4)->where('dinding_rumah','>=',3)->where('bahanbakar_masak','>=',3)->where('frekuensi_makan',4)->where('frekuensi_makan',4)->where('tabungan', '>=' , 3);;    
                    });
            $jumlahPenduduk = $penduduks->count();
            $penduduks = $penduduks->paginate(10);
            $lokasi = 'Jember';
        }
        return view('dashboard.bantuan.rastrada',compact('desas','kecamatans','penduduks','jumlahPenduduk','lokasi'));
    }    

    public function downloadRastrada(){
        
        if(Auth::user()->role <> 1){
            return redirect('dashboard');
        }
        return Excel::download(new RastradaExport, 'rastrada.xlsx');
    }

}