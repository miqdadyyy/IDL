<?php

namespace App\Http\Controllers;
use App\Desa;
use App\Kecamatan;
use App\Penduduk;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Session;
use Yajra\Datatables\Datatables;
use Auth;
class PendudukController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('staff');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        // $start = microtime(true);
        // Execute the query
       $kecamatans = Kecamatan::all();
       $desas = Desa::all();
       if(!$request->has('kecamatan')){
            $penduduks = Penduduk::paginate(10);
       }
       else{
            $penduduks = new Penduduk;
            if($request->kecamatan <> 'all'){
                $penduduks = $penduduks->where('kecamatan_id',$request->kecamatan);
            }
            if($request->desa <> 'all'){
                $penduduks = $penduduks->where('desa_id',$request->desa);
                 Session::flash('desa_id',$request->desa);
            }
            $penduduks = $penduduks->paginate(10);
            Session::flash('kecamatan',$request->kecamatan);

       }
        // $time = microtime(true) - $start;
        // dd($time);
        return view('dashboard.penduduk.index',compact('kecamatans','desas','penduduks'));
    }

     public function belumVerval()
    {
        if(Auth::user()->role <> 1){
            return redirect('dashboard');
        }   
        $penduduks = Penduduk::doesntHave('info')->paginate(10);
        return view('dashboard.penduduk.belumVerval',compact('penduduks'));
    }


}
