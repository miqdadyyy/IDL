<?php

namespace App\Http\Controllers;
use App\Desa;
use App\Kecamatan;
use App\Penduduk;
use App\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Session;
use Yajra\Datatables\Datatables;
use Hash;
use Auth;
use File;
use Image;
class PencarianController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('staff')->except('getDesa');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    
    public function penduduk()
    {
        $kecamatans = Kecamatan::all();
        return view('dashboard.pencarian.penduduk',compact('kecamatans'));
    }

    public function filterPenduduk(Request $request)
    {
        if($request->type == 1){
            $no_ktp = $request->no_ktp;
            $penduduks = Penduduk::where('no_ktp',$no_ktp)->get();
            $keyword = 'No KTP : ' . $request->no_ktp;
        }
        elseif($request->type == 2){
            $penduduks = Penduduk::where('no_kk',$request->no_kk)->get();
            $keyword = 'No KK : ' . $request->no_kk;
        }
        else{

            $penduduks = Penduduk::where('nama', 'like', '%' . $request->name . '%');
            if($request->desa <> 'all'){
                $penduduks = $penduduks->where('desa_id',$request->desa);
            }
            if($request->kecamatan <> 'all'){
                $penduduks = $penduduks->where('kecamatan_id',$request->kecamatan);

            }
            $penduduks = $penduduks->get();
            $keyword = 'Nama : ' . $request->name ;
        }

        Session::flash('keyword',$keyword);
        return view('dashboard.pencarian.filter',compact('penduduks'));
    }
    public function getDesa($id)
    {
        $desas = Kecamatan::find($id)->desas->pluck('name','id');
        return json_encode($desas);
    }


}