<?php

namespace App\Http\Controllers;
use App\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Session;
use Yajra\Datatables\Datatables;
use App\Http\Requests\ChangeAvatarRequest;
use Hash;
use Auth;
use File;
use Image;
class AkunController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    
    public function index()
    {
        return view('dashboard.akun');
    }

    public function update(ChangeAvatarRequest $request)
    {   
        $user = Auth::user();
        $user->name = $request->name;
        $user->email = $request->email;
        $user->telp = $request->telp;
        if($request->hasFile('avatar')){
            $avatar = $request->file('avatar');
            $filename = uniqid() . '.' . $avatar->getClientOriginalExtension();
             // Delete current image before uploading new image
            if ($user->avatar <> 'default.png') {
                // $file = public_path('uploads/avatars/' . $user->avatar);
                $file = 'uploads/avatar/' . $user->avatar;
                //$destinationPath = 'uploads/' . $id . '/';
                if (File::exists($file)) {
                    unlink($file);
                }
            }
            Image::make($avatar)->save( public_path('/uploads/avatar/' . $filename ) ,70 );

        $user->avatar = $filename;
        }
        $user->save();
        Session::flash('success','Anda berhasil merubah profile anda');
        return redirect()->back();
    }

    public function updatePassword(Request $request)
    {
        $user = Auth::user();
        $user->password = Hash::make($request->password);
        $user->save();
        Session::flash('password','Anda berhasil mengganti password anda');
        return redirect()->back();   
    }

}