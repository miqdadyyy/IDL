<?php

namespace App\Http\Controllers\Staff;
use App\Desa;
use App\Kecamatan;
use App\Pekerjaan;
use App\Penduduk;
use App\Penduduk_Info;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Session;
use Yajra\Datatables\Datatables;
use App\Http\Controllers\Controller;
use Auth;

class PendudukController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    
    public function __construct()
    {
        $this->middleware('auth');

    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        // $start = microtime(true);
        // Execute the query
       $kecamatans = Kecamatan::orderBy('name')->get();
       $desas = Desa::orderBy('name')->get();
       $id = Auth::user()->id;
       if(!$request->has('kecamatan')){
            $penduduks = Penduduk::where('petugas_id',$id)->paginate(10);
       }
       else{

            $penduduks = Penduduk::where('petugas_id',$id);
            if($request->kecamatan <> 'all'){
                $penduduks = $penduduks->where('kecamatan_id',$request->kecamatan);
            }
            if($request->desa <> 'all'){
                $penduduks = $penduduks->where('desa_id',$request->desa);
                Session::flash('desa_id',$request->desa);
            }
            if($request->nama <> ''){
                $penduduks = $penduduks->where('nama','like','%' . $request->nama . '%');
            }
            $penduduks = $penduduks->paginate(10);
            Session::flash('kecamatan',$request->kecamatan);

       }
        // $time = microtime(true) - $start;
        // dd($time);
        return view('dashboard.penduduk.staff.index',compact('kecamatans','desas','penduduks'));
    }

    public function create()
    {
        if(Auth::user()->role == 2){
            return redirect('dashboard');
        }
        $kecamatans = Kecamatan::orderBy('name')->get();
        $desas = Desa::all();
        $pekerjaans = Pekerjaan::orderBy('name')->get();
        return view('dashboard.penduduk.staff.create',compact('kecamatans','desas','pekerjaans'));
    }

    public function edit($id)
    {
        $penduduk = Penduduk::findOrFail($id);
        $kecamatans = Kecamatan::orderBy('name')->get();
       $desas = Desa::orderBy('name')->get();
       $pekerjaans = Pekerjaan::orderBy('name')->get();
        if($penduduk->petugas_id <> Auth::user()->id && Auth::user()->role <> '1'){
            Session::flash('salah','Anda tidak memiliki hak akses untuk melakukan aktivitas tersebut');
            return redirect()->route('view-staff');
        }

        return view('dashboard.penduduk.staff.edit',compact('penduduk','kecamatans','desas','pekerjaans'));
    }

    public function store(Request $request)
    {
        if(Auth::user()->role == 2){
            return redirect('dashboard');
        }
        $penduduk = new Penduduk;
        $penduduk->nama = strtoupper($request->nama);
        $penduduk->petugas_id = Auth::user()->id;
        $penduduk->no_ktp = $request->no_ktp;
        $penduduk->no_kk = $request->no_kk;
        $penduduk->tempat_lahir = strtoupper($request->tempat_lahir);
        $tanggal_lahir = $request->tanggal_lahir;
        $new_tanggal_lahir = Carbon::parse($tanggal_lahir)->format('Y-m-d');
        $penduduk->tanggal_lahir = $new_tanggal_lahir;
        $penduduk->alamat = strtoupper($request->alamat);
        $penduduk->desa_id = $request->desa;
        $penduduk->kecamatan_id = $request->kecamatan;
        $penduduk->pendidikan_id = $request->pendidikan;
        $penduduk->pekerjaan_id = $request->pekerjaan;
        $penduduk->save();
        Session::flash('success','Anda berhasil menambahkan data penduduk ' . $penduduk->nama);
        if(Auth::user()->role == 1){
            return redirect('dashboard/penduduk');
        }
        else{   
            return redirect('dashboard/staff/penduduk');
        }

    }

    public function update(Request $request,$id)
    {
        $penduduk = Penduduk::findOrFail($id);

        $penduduk->nama = strtoupper($request->nama);
        $penduduk->petugas_id = Auth::user()->id;
        $penduduk->no_ktp = $request->no_ktp;
        $penduduk->no_kk = $request->no_kk;
        $penduduk->tempat_lahir = strtoupper($request->tempat_lahir);
        $tanggal_lahir = $request->tanggal_lahir;
        $new_tanggal_lahir = Carbon::parse($tanggal_lahir)->format('Y-m-d');
        $penduduk->tanggal_lahir = $new_tanggal_lahir;
        $penduduk->alamat = strtoupper($request->alamat);
        $penduduk->desa_id = $request->desa;
        $penduduk->kecamatan_id = $request->kecamatan;
        $penduduk->pendidikan_id = $request->pendidikan;
        $penduduk->pekerjaan_id = $request->pekerjaan;
        $penduduk->save();
        Session::flash('success','Anda berhasil merubah data penduduk ' . $penduduk->nama);
        return redirect('dashboard/staff/penduduk');
    }

    public function verval()
    {
        $id = Auth::user()->id;
        $penduduks = Penduduk::where('petugas_id',$id)->doesntHave('info')->orderBy('nama','asc')->orderBy('kecamatan_id')->paginate(10);
        return view('dashboard.penduduk.staff.verval',compact('penduduks'));
    }

    public function vervalShow($id){
        $penduduk = Penduduk::findOrFail($id);
        if($penduduk->petugas_id <> Auth::user()->id && Auth::user()->role <> '1'){
            Session::flash('salah','Anda tidak memiliki hak akses untuk melakukan aktivitas tersebut');
            return redirect()->route('verval-show');
        }
        return view('dashboard.penduduk.staff.vervalShow',compact('penduduk'));
    }

    public function vervalCreate($id)
    {
        $penduduk = Penduduk::findOrFail($id);

        if($penduduk->petugas_id <> Auth::user()->id && Auth::user()->role <> '1'){
            Session::flash('salah','Anda tidak memiliki hak akses untuk melakukan aktivitas tersebut');
            return redirect()->route('verval-show');
        }
        if($penduduk->info()->exists()){
            Session::flash('salah','Anda tidak memiliki hak akses untuk melakukan aktivitas tersebut');
            return redirect()->route('verval-show');
        }
        return view('dashboard.penduduk.staff.vervalCreate',compact('penduduk'));
    }

    public function vervalStore(Request $request,$id)
    {
        $penduduk = Penduduk::findOrFail($id);
        if($penduduk->info()->exists()){
            Session::flash('salah','Anda tidak memiliki hak akses untuk melakukan aktivitas tersebut');
            return redirect()->route('verval-show');
        }
        $info = new Penduduk_Info;
        $info->penduduk_id = $id;
        $info->status_rumah = $request->status_rumah;
        $info->luas_rumah = $request->luas_rumah;
        $info->lantai_rumah = $request->lantai_rumah;
        $info->dinding_rumah = $request->dinding_rumah;
        $info->fasilitas_mck = $request->fasilitas_mck;
        $info->sumber_penerangan = $request->sumber_penerangan;
        $info->sumber_air = $request->sumber_air;
        $info->bahanbakar_masak = $request->bahanbakar_masak;
        $info->jumlah_konsumsi = $request->jumlah_konsumsi;
        $info->pembelian_pakaian = $request->pembelian_pakaian;
        $info->frekuensi_makan = $request->frekuensi_makan;
        $info->biaya_berobat = $request->biaya_berobat;
        $info->pendapatan_KK = $request->pendapatan_KK;
        $info->pendidikan_KK =  $request->pendidikan_KK;
        $info->tabungan = $request->tabungan;
        $info->save();
        Session::flash('success','Anda berhasil melakukan verifikasi dan validasi untuk ' . $penduduk->nama);
        return redirect()->route('verval-show');

    }


}
