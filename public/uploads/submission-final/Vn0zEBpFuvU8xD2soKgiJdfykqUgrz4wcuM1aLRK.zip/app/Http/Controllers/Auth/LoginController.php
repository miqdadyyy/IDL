<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use Session;
use Auth;
class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = '/dashboard';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    // public function login(Request $request){
    //     $credential = [
    //         'email' => $request->email,
    //         'password' => $request->password,
    //     ];
    //     $foo =  false ;

    //     if (Auth::attempt($credential)) {   
    //             return redirect('dashboard');
    //     } 
    //     else{
    //         Session::flash('salah','Username atau Password salah');
    //         return back();
    //     }
    // }

    public function login(Request $request)
    {
        $username = $request->username ;
        $password = $request->password ;
        if(strpos($username,'@') !== false){
            $credential = [
            'email' => $username,
            'password' => $request->password,
            ];
        }
        else {
            $credential = [
            'username' => $username,
            'password' => $request->password,
            ];
        }
        if (Auth::attempt($credential)) {
            return redirect()->back();
        } else {
            Session::flash('salah','Username atau Password salah');
            return redirect()->back();
        }
    }
}
