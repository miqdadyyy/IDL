<?php

namespace App\Http\Controllers;
use App\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Session;
use Yajra\Datatables\Datatables;
use App\Http\Requests\ChangeAvatarRequest;
use Hash;
class PengaturanController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('admin');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    
    public function user()
    {
        $users = User::all();
        return view('dashboard.pengaturan.user',compact('users'));
    }    

    public function userTambah()
    {
        return view('dashboard.pengaturan.userTambah');
    }

    public function userStore(Request $request)
    {   
        $role = $request->role ;
        if($role == 1){
            $namarole = 'Administrator';
        }
        elseif($role == 2){
            $namarole = 'Staff';
        }
        elseif($role == 3){
            $namarole = 'Operator';
        }
        $user = new User;
        $user->name = $request->name;
        $user->username = $request->username;
        $user->password = Hash::make($request->password);
        $user->email = $request->email;
        $user->role = $role;
        $user->save();
        Session::flash('success','Anda berhasil menambahkan ' . $user->name . ' sebagai ' . $namarole);
        return redirect()->route('view-user');
    }

}