<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ChangeAvatarRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
           'avatar' => 'max:500',
           'telp' => 'regex:/(08)[0-9]/|max:14|min:9'
        ];
    }
    public function messages()
    {
        return [
            'avatar.max' => 'Maaf, ukuran foto harus dibawah 500 Kb',
            'telp.regex' => 'Nomor telepon harus diawali 08 dan harus berupa angka ya !',
            'telp.min' => 'Nomor telepon minimal 9 karakter', 
            'telp.max' => 'Nomor telepon maksimal 14 karakter',  
        ];
    }

}
