<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;
use App\Penduduk_Info;
class Penduduk extends Model
{
	protected $table = 'penduduks';
	protected $appends = ['normaldate','normalkk','normalktp','inputdate'];
    
    public function info()
    {
        return $this->hasOne('App\Penduduk_Info');
    }

    public function desa()
    {
        return $this->belongsTo('App\Desa','desa_id');
    }
    public function petugas()
    {
        return $this->belongsTo('App\User','petugas_id');
    }
    public function pekerjaan()
    {
    	return $this->belongsTo('App\Pekerjaan','pekerjaan_id');
    }
    public function getNormalKkAttribute(){
    	// dd(Penduduk_Info::find(1));
    	// dd($this->no_kk);
    	if($this->no_kk == ''){
    		$no_kk = 'No Data';
    	}
    	else{
    		$no_kk = $this->no_kk;
    	}
    	return $no_kk;
    }
    public function getNormalKtpAttribute(){
    	// dd(Penduduk_Info::find(1));
    	// dd($this->no_kk);
    	if($this->no_ktp == ''){
    		$no_ktp = 'No Data';
    	}
    	else{
    		$no_ktp = $this->no_ktp;
    	}
    	return $no_ktp;
    }
    public function getNormalDateAttribute()
    {	
    	if($this->tanggal_lahir == "0000-00-00"){
    		$tanggal_lahir = 'No Data';
    	}else{	
    		$tanggal_lahir = Carbon::parse($this->tanggal_lahir)->format('d M Y');
    	}
    	return $tanggal_lahir;
    }

    public function getInputDateAttribute()
    {
        return Carbon::parse($this->tanggal_lahir)->format('d/m/Y');
    }

}
