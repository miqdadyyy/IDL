<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Penduduk_Info extends Model
{
 
	protected $table = 'penduduk_info'; 
	protected $primaryKey = 'penduduk_id';  
	public $timestamps = false;

}
